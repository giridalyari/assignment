from tkinter import *
from register import *
from studentsystem import *
from systemconnection import *

class Loginview:
    def __init__(self):
        self.wn=Tk()
        self.wn.title("Login System")
        self.wn.geometry("350x350")
        self.wn.configure(bg="grey")
        title = Label(self.wn,text="Login User",bg='black',fg='blue',font=("new times roman",16,"bold"), width=20,height=2)
        title.pack(side=TOP,fill=X)
        lbl_name=Label(self.wn,text='Username ',bg='white',fg='black',width=9,height=1,font=('arial',12,"bold"))
        lbl_name.place(x=0,y=50)
        self.txt_name=Entry(self.wn,width=20)
        self.txt_name.place(x=100,y=54)
        lbl_password = Label(self.wn, text='Password',bg='white', fg='black', width=9, height=1,font=('areal',12,"bold"))
        lbl_password.place(x=0,y=90)
        self.txt_password = Entry(self.wn, width=20)
        self.txt_password.place(x=100,y=95)
        btn_name=Button(self.wn,text="Login",width=10,fg='white',command=self.adddata,bg='black',font=('areal',12,"bold"))
        btn_name.place(x=60,y=130)
        btn_password = Button(self.wn, text="Register", width=10,fg='white',bg='black',font=('arial',12,"bold"),
                              command = self.call_register)
        btn_password.place(x=60,y=170)
        self.wn.mainloop()
    def call_register(self):
        self.wn.destroy()
        return Register()
    def adddata(self):
        un = self.txt_name.get()
        pw = self.txt_password.get()
        try:
            if un =="" or pw=="":
                messagebox.showerror("error box","Fill Username and Passsword to Login")
            else:
                self.register = Login()
                uss = self.register.login(un, pw)
                if len(uss)==1:
                    self.wn.destroy()
                    StudentView()
                else:
                    messagebox.showerror("error box", "Invalid username and password")
        except Exception:
            messagebox.showerror('Errorbox')

Loginview()