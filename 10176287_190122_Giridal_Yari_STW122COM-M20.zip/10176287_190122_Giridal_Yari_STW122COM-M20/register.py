from tkinter import *
from tkinter import messagebox
from systemconnection import *
class Register:
    def __init__(self):
        self.wn=Tk()
        self.wn.title("Login System")
        self.wn.geometry("400x480")
        self.wn.configure(bg="black")
        self.register_login = Login()
        title = Label(self.wn,text="Register User",bg='white',fg='black',font=("arial",15,"bold"), width=30,height=1)
        title.pack(side=TOP,fill=X)
        self.lbl_name=Label(self.wn,text='Name ',bg='yellow',fg='black',width=10,height=2,font=("new times roman",13,"bold",))
        self.lbl_name.place(x=0,y=50)
        self.txt_name=Entry(self.wn,width=30)
        self.txt_name.place(x=100,y=63)
        self.lbl_email = Label(self.wn, text='Email', bg='yellow', fg='black', width=10, height=2,font=("new times roman",13,"bold",))
        self.lbl_email.place(x=0,y=100)
        self.txt_email = Entry(self.wn, width=30)
        self.txt_email.place(x=100,y=110)
        self.lbl_contact = Label(self.wn, text='Contact', bg='yellow', fg='black', width=10, height=2,font=("new times roman",13,"bold",))
        self.lbl_contact.place(x=0,y=150)
        self.txt_contact = Entry(self.wn, width=30)
        self.txt_contact.place(x=100,y=160)
        self.lbl_address = Label(self.wn, text='Address', bg='yellow', fg='black', width=10, height=2,font=("new times roman",13,"bold",))
        self.lbl_address.place(x=0,y=200)
        self.txt_address = Entry(self.wn, width=30)
        self.txt_address.place(x=100,y=210)
        self.lbl_username = Label(self.wn, text='Username ', bg='yellow', fg='black', width=10, height=2,font=("new times roman",13,"bold",))
        self.lbl_username.place(x=0,y=250)
        self.txt_username = Entry(self.wn, width=30)
        self.txt_username.place(x=100,y=260)
        self.lbl_password = Label(self.wn, text='Password', bg='yellow', fg='black', width=10, height=2,font=("new times roman",13,"bold",))
        self.lbl_password.place(x=0,y=300)
        self.txt_password = Entry(self.wn, width=30)
        self.txt_password.place(x=100,y=310)
        btn_register = Button(self.wn,text="Register",width=10,fg='white',bg='blue', font=('arial',12,"bold"),command=self.add_register)
        btn_register.place(x=80,y=350)
        btn_back = Button(self.wn, text="Exit", width=10,  fg='white', bg='blue',
                          font=('arial', 12, "bold"),command=self.wn.destroy)
        btn_back.place(x=80,y=410)
        self.wn.mainloop()
    def add_register(self):
        name = self.txt_name.get()
        email = self.txt_email.get()
        contact = self.txt_contact.get()
        address = self.txt_address.get()
        username = self.txt_username.get()
        password = self.txt_password.get()
        try:
            if name == "" or email == "" or contact == "" or address == "" or username == "" or password == "":
                messagebox.showerror("errorbox", "All field are needed")
            else:
                if self.register_login.register(name, email, contact, address, username, password):
                    messagebox.showinfo("dashbord", "Register Success")
                else:
                    messagebox.showerror("errorbox", "Can't Register")
        except Exception:
            messagebox.showerror('Errorbox')
