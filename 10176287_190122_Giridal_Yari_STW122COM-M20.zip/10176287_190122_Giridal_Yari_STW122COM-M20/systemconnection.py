from connection import *
class Student_record:
    def __init__(self):
        self.connection = Connection()
    def add_student(self, roll_no, name, email, gender, contact_no, date_of_birth, address):
        qry = "insert into students values (%s, %s, %s, %s, %s, %s, %s)"
        value = (roll_no, name, email, gender, contact_no, date_of_birth, address)
        self.connection.insert_update_delete(qry, value)
        return True
    def update_student(self, index, roll_no, name, email, gender, contact_no, date_of_birth, address):
        qry = "update students set roll_no = %s, name = %s, email = %s, gender = %s, contact_no = %s, date_of_birth = %s, address = %s where roll_no = %s"
        value = (roll_no, name, email, gender, contact_no, date_of_birth, address, index)
        self.connection.insert_update_delete(qry, value)
        return True
    def delete_student(self, index):
        qry =" delete from students where roll_no = %s"
        value = (index,)
        self.connection.insert_update_delete(qry, value)
        return True
    def show_student(self):
        qry = "select * from students"
        all_student = self.connection.fetch_data(qry)
        return all_student
    def search_student(self, a, b):
        qry = "select * from students WHERE " + a + " like '" + b + "%'"
        all = self.connection.fetch_data(qry)
        return all

class Login:
    def __init__(self):
        self.conn=Connection()
    def register(self,name,email,contact,address,username,password):
        qry = "insert into userss (name,email,contact,address,username,password) values ( %s,%s,%s,%s,%s,%s)"
        value = (name,email,contact,address,username,password)
        self.conn.insert_update_delete(qry,value)
        return True
    def login(self, username, password):
        qry = "select * from userss where username = %s and password = %s"
        value = (username, password)
        data = self.conn.fetch_data_parameter(qry, value)
        return data