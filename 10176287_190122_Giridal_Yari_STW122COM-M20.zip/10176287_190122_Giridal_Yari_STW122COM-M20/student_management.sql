create database studentsystem;
use studentsystem;
create table if not exists students (roll_no int primary key, name varchar(50), email varchar(30), gender varchar(20), contact_no varchar(10), 
date_of_birth varchar(20), address varchar(100));
select * from students;
create table userss(id int primary key auto_increment,name varchar(20),email varchar(50),contact varchar(10),address varchar(20), 
username varchar(20),password varchar(20));
select * from userss;
