from tkinter import *
from tkinter import ttk
from systemconnection import *
from tkinter import messagebox

class StudentView:
    def __init__(self):
        self.update_index = ""
        self.root = Tk()
        self.root.title("Student Management System")
        self.root.geometry("1700x700+0+0")
        self.root.configure(bg="light blue")
        self.student_record = Student_record()
        self.title = Label(self.root, text = "Student Management System",bd=10,relief = GROOVE, font=("arial", 40, "bold"), bg="white", fg="blue")
        self.title.pack(side=TOP, fill =X)
    #======================manageframe=============================================================================================
        manage_frame = Frame(self.root, bd=4, relief = RIDGE, bg="crimson")
        manage_frame.place(x=20, y=100, width=450, height=560)
        m_title = Label(manage_frame, text= "Managae Students", bg="crimson", font=("arial", 25, "bold"), fg="white")
        m_title.grid(row=0, columnspan=2, pady=10, padx=30)
        self.lbl_roll = Label(manage_frame, text="Roll No.", bg="crimson", font=("arial", 15, "bold"), fg="white")
        self.lbl_roll.grid(row=1, column=0, pady=10, padx=10, sticky = "w")
        self.entry_roll = Entry(manage_frame,font=("arial", 15, "bold"), bd=6 )
        self.entry_roll.grid(row=1, column=1)
        self.lbl_name = Label(manage_frame, text="Name", bg="crimson", font=("arial", 15, "bold"), fg="white")
        self.lbl_name.grid(row=2, column=0, pady=10, padx=10, sticky="w")
        self.entry_name = Entry(manage_frame,  font=("arial", 15, "bold"), bd=6)
        self.entry_name.grid(row=2, column=1)
        self.lbl_email = Label(manage_frame, text="Email", bg="crimson", font=("arial", 15, "bold"), fg="white")
        self.lbl_email.grid(row=3, column=0, pady=10, padx=10, sticky="w")
        self.entry_email = Entry(manage_frame,  font=("arial", 15, "bold"), bd=6)
        self.entry_email.grid(row=3, column=1)
        self.lbl_gender = Label(manage_frame, text="Gender: ", bg="crimson", font=("arial", 15, "bold"), fg="white")
        self.lbl_gender.grid(row=4, column=0, pady=10, padx=10, sticky="w")
        self.combox_gender = ttk.Combobox(manage_frame, width=19, state="readonly", font=("arial", 15, "bold"))
        self.combox_gender['values'] = ["Male", "Female", "other"]
        self.combox_gender.current(0)
        self.combox_gender.grid(row=4, column=1)
        self.lbl_contact = Label(manage_frame, text="Contact No.", bg="crimson", font=("arial", 15, "bold"), fg="white")
        self.lbl_contact.grid(row=5, column=0, pady=10, padx=10, sticky="w")
        self.entry_contact = Entry(manage_frame, font=("arial", 15, "bold"), bd=6)
        self.entry_contact.grid(row=5, column=1)
        self.lbl_dob = Label(manage_frame, text="D.O.B", bg="crimson", font=("arial", 15, "bold"), fg="white")
        self.lbl_dob.grid(row=6, column=0, pady=10, padx=10, sticky="w")
        self.entry_dob = Entry(manage_frame, font=("arial", 15, "bold"), bd=6)
        self.entry_dob.grid(row=6, column=1)
        self.lbl_address = Label(manage_frame, text="Address", bg="crimson", font=("arial", 15, "bold"), fg="white")
        self.lbl_address.grid(row=7, column=0, pady=10, padx=10, sticky="w")
        self.entry_address = Entry(manage_frame, font=("arial", 15, "bold"), bd=6)
        self.entry_address.grid(row=7, column=1)
    #=========================================btn frame====================================================================
        btn_frame = Frame(manage_frame, bd=7, relief=RIDGE, bg="crimson")
        btn_frame.place(x=5, y=450, width=435, height=75)
        btn_add = Button(btn_frame, text="Add", width=12, height=2, bd=3, command = self.add_student)
        btn_add.grid(row=0, column=0, padx=5, pady=10)
        btn_update = Button(btn_frame, text="Update", width=12, height=2, bd=3, command = self.update_student)
        btn_update.grid(row=0, column=1, padx=5, pady=10)
        btn_delete = Button(btn_frame, text="Delete", width=12, height=2, bd=3, command = self.delete_student)
        btn_delete.grid(row=0, column=2, padx=5, pady=10)
        btn_clear = Button(btn_frame, text="Clear", width=12, height=2, bd=3, command = self.clear)
        btn_clear.grid(row=0, column=3, padx=2, pady=10)
    # ======================details frame============================================================================================
        details_frame = Frame(self.root, bd=4, relief=RIDGE, bg="crimson")
        details_frame.place(x=500, y=100, width=1000, height=560)
        self.lbl_search = Label(details_frame, text="Search by", bg="crimson", font=("arial", 15, "bold"), fg="white")
        self.lbl_search.grid(row=0, column=0, pady=10, padx=10, sticky="w")
        self.combo_search = ttk.Combobox(details_frame, font=("arial", 14, "bold"), state="readonly")
        self.combo_search["values"] = ("roll_no", "name")
        self.combo_search.grid(row=0, column=1, pady=10, padx=10, sticky="w")
        self.txt_search = Entry(details_frame, font=("arial", 15, "bold"), bd=6, relief=GROOVE)
        self.txt_search.grid(row=0, column=2, pady=10, padx=10, sticky="w")
        btn_search = Button(details_frame, text = "Search", font=("arial", 12, "bold"), command = self.search_student)
        btn_search.grid(row=0, column=3, padx=20, pady=10)
        btn_all = Button(details_frame, text="Show All", font=("arial", 12, "bold"), command = self.show_info)
        btn_all.grid(row=0, column=4, padx=20, pady=10)
        btn_all = Button(details_frame, text="Exit", font=("arial", 12, "bold"), command = self.root.destroy)
        btn_all.grid(row=0, column=5, padx=20, pady=10)
    #==================================Table Frame=======================================================================
        table_frame = Frame(details_frame, bd=10,relief= RIDGE, bg="crimson")
        table_frame.place(x=20, y=70, width=950, height=460)
        scroll_x = Scrollbar(table_frame, orient = HORIZONTAL)
        scroll_y = Scrollbar(table_frame, orient=VERTICAL)
        self.student_table = ttk.Treeview(table_frame, columns=("roll", "name", "email", "gender","contact","dob", "address"),
                                          xscrollcommand = scroll_x.set,yscrollcommand= scroll_y.set)
        scroll_x.pack(side=BOTTOM, fill = X)
        scroll_y.pack(side=RIGHT, fill=Y)
        scroll_x.config(command = self.student_table.xview)
        scroll_y.config(command = self.student_table.yview)
        self.student_table.heading("roll", text="Roll No")
        self.student_table.heading("name", text="Name")
        self.student_table.heading("email", text="Email")
        self.student_table.heading("gender", text="Gender")
        self.student_table.heading("contact", text="Contact")
        self.student_table.heading("dob", text="D.O.B")
        self.student_table.heading("address", text="Address")
        self.student_table.column("roll", anchor="center")
        self.student_table.column("name", anchor="center")
        self.student_table.column("email", anchor="center")
        self.student_table.column("gender", anchor="center")
        self.student_table.column("contact", anchor="center")
        self.student_table.column("dob",  anchor="center")
        self.student_table.column("address", anchor="center")
        self.student_table["show"] = "headings"
        self.student_table.pack(fill = BOTH, expand = 1)
        self.show_info()
        self.root.mainloop()
    def add_student(self):
        roll = self.entry_roll.get()
        name = self.entry_name.get()
        email = self.entry_email.get()
        gender = self.combox_gender.get()
        contact = self.entry_contact.get()
        dob = self.entry_dob.get()
        addres = self.entry_address.get()
        if roll == "" or name == "" or email == "" or gender == "" or contact == "" or dob == "" or addres == "":
            messagebox.showerror("Error box", "All fields are required!")
        else:
            if self.student_record.add_student(roll, name, email, gender, contact, dob, addres):
               messagebox.showinfo("Message box", "Successfully added")
               self.show_info()
            else:
                messagebox.showerror("Error box", "Can't added!")
    def update_student(self):
        if self.update_index == "":
            messagebox.showerror("error box", "Select first!")
        else:
            roll = self.entry_roll.get()
            name = self.entry_name.get()
            email = self.entry_email.get()
            gender = self.combox_gender.get()
            contact = self.entry_contact.get()
            dob = self.entry_dob.get()
            addres = self.entry_address.get()
            try:
                if self.student_record.update_student(int(self.update_index), roll, name, email, gender, contact, dob, addres):
                    messagebox.showinfo("student dashboard", "Successfully updated")
                    self.show_info()
                else:
                    messagebox.showerror("student dashboard", "Can't updated!")
            except Exception:
                messagebox.showerror("error box", "error occur!")
    def delete_student(self):
        if self.student_record.delete_student(int(self.update_index)):
            messagebox.showinfo("dashboard", "Deleted successfully")
            self.show_info()
        else:
            messagebox.showerror("Error box", "Can't delete!")
    def show_info(self):
        all_students = self.student_record.show_student()
        self.student_table.delete(*self.student_table.get_children())
        for i in all_students:
            self.student_table.insert("", "end", text = i[0], value = (i[0], i[1], i[2], i[3], i[4], i[5], i[6]))
        self.student_table.bind("<Double-1>", self.select)
    def select(self, event):
        b = self.student_table.selection()[0]
        self.update_index = self.student_table.item(b, 'text')
        selected_data = self.student_table.item(b, 'values')
        self.entry_roll.delete(0, 'end')
        self.entry_roll.insert(0, selected_data[0])
        self.entry_name.delete(0, 'end')
        self.entry_name.insert(0, selected_data[1])
        self.entry_email.delete(0, 'end')
        self.entry_email.insert(0, selected_data[2])
        self.combox_gender.delete(0, 'end')
        self.combox_gender.insert(0, selected_data[3])
        self.entry_contact.delete(0, 'end')
        self.entry_contact.insert(0, selected_data[4])
        self.entry_dob.delete(0, 'end')
        self.entry_dob.insert(0, selected_data[5])
        self.entry_address.delete(0, 'end')
        self.entry_address.insert(0, selected_data[6])
    def clear(self):
        self.entry_roll.delete(0, 'end')
        self.entry_name.delete(0, 'end')
        self.entry_email.delete(0, 'end')
        self.combox_gender.delete(0, 'end')
        self.entry_contact.delete(0, 'end')
        self.entry_dob.delete(0, 'end')
        self.entry_address.delete(0, 'end')
    def search_student(self):
        a = self.combo_search.get()
        b = self.txt_search.get()
        self.student_table.delete(*self.student_table.get_children())
        C = self.student_record.search_student(a, b)
        for i in C:
            self.student_table.insert("", 'end', value = (i[0], i[1], i[2], i[3], i[4], i[5], i[6]))