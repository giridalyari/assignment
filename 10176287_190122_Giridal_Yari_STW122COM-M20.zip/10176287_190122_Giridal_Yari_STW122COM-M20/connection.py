import mysql.connector
class Connection:
    def __init__(self):
        self.connection = mysql.connector.connect(user="root", host="localhost", password="yari@2019", database="studentsystem")
        self.cur = self.connection.cursor()
    def insert_update_delete(self, qry, value):
        self.cur.execute(qry, value)
        self.connection.commit()
        return True
    def fetch_data(self, qry):
        self.cur.execute(qry)
        self.data = self.cur.fetchall()
        return self.data
    def fetch_data_parameter(self, qry, value):
        self.cur.execute(qry, value)
        data = self.cur.fetchall()
        return data