import unittest
from systemconnection import *
class Student_recordTest(unittest.TestCase):
    student = Student_record()
    def test_add(self):
        a = self.student.add_student(18 ,"test_name", "test_email", "test_gender", 9853235562, "test_date_of_birth", "test_address")
        self.assertTrue(a)
    def test_update(self):
        b = self.student.update_student(3, 10, "test_name", "test_email", "test_gender", 5646464646, "test_date_of_birth", "test_address")
        self.assertTrue(b)
    def test_delete(self):
        c = self.student.delete_student(2)
        self.assertTrue(c)
    def test_show_all(self):
        d = self.student.show_student()
        self.assertTrue(d)
    def test_search(self):
        e = self.student.search_student("1", "1")
        self.assertTrue(e)

class LoginTest(unittest.TestCase):
    login = Login()
    def test_registe(self):
        a = self.login.register("test_name", "test_email", 589865665, "test_address", "test_username", "test_password")
        self.assertTrue(a)
    def test_login(self):
        b =self.login.login("Giridal", "yari@2019")
        self.assertTrue(b)