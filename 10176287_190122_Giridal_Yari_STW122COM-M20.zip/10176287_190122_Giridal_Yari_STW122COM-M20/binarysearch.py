def binary_search_iterative(list, key):
    start = 0
    end = len(list) - 1
    while start <= end:
        mid = (start + end) // 2
        if list[mid][0] == key:
            return mid
        elif list[mid][0] > key:
            end = mid - 1
        else:
            start = mid + 1
    return -1